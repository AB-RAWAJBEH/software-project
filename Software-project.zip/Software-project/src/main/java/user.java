public class user
{
	protected String name;
	protected String username;
	protected String password;
	protected String pass;
	protected String phonenumber;
	protected String city;
	protected boolean islogged;
	


}